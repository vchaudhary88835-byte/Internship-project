# Full Stack Internship — Frontend Projects

This bundle contains three frontend-only student project prototypes:
1. E-commerce Store
2. Social Media Platform
3. Project Management Tool

## Requirements
- Windows 10/11
- VS Code (recommended) or any text editor
- A modern browser (Chrome, Edge, Firefox)

## Run a project
1. Extract this ZIP file.
2. Open the extracted folder in VS Code.
3. Open one project folder, such as `project1-ecommerce`.
4. Open `index.html` in your browser. Recommended: install the VS Code extension **Live Server**, right-click `index.html`, and choose **Open with Live Server**.
5. Try all features listed in the testing checklist below.

## Folder structure
Each project has:
- `index.html` — page structure
- `style.css` — responsive styling
- `script.js` — app behavior and localStorage persistence

## Testing checklist
### Project 1 — E-commerce
- Search for a product.
- Add two different products to the cart.
- Increase/decrease quantity and remove an item.
- Clear the cart.
- Add an item and place a demo order.
- Save a demo profile, refresh, and check that it remains.
- Note: no payment is taken and no server order is created.

### Project 2 — Social Media
- Change the display name.
- Publish a post.
- Like and unlike a post.
- Add a comment.
- Follow and unfollow a sample member.
- Refresh and verify the data persists.

### Project 3 — Project Management
- Add a project and select it.
- Add a task with an assignee and due date.
- Move the task between To do, In progress, and Done.
- Add a comment to a task.
- Delete a task and then delete a project.
- Refresh and verify the remaining data persists.

## Important limitation
These are frontend-only demos. `localStorage` stores data in the current browser on the current device. It is not a shared database and is not secure authentication. Do not enter real passwords, payment details, or confidential information. A true full-stack version needs a backend (for example Node.js + Express or Django), a database, and server-side authentication.

## Submission suggestions
- Capture screenshots of each project with key features visible.
- Keep your code files and screenshots in separate folders.
- Follow the internship provider's exact submission form and instructions.
- Describe these honestly as frontend prototypes unless you add and test a backend.
